var searchData=
[
  ['otf2_5fallocate',['otf2_allocate',['../structOTF2__MemoryCallbacks.html#ae0e7291dfed047c4ee58fe42ea242412',1,'OTF2_MemoryCallbacks']]],
  ['otf2_5ffree_5fall',['otf2_free_all',['../structOTF2__MemoryCallbacks.html#a0c655034dddfe0e21f3be0a362d8d229',1,'OTF2_MemoryCallbacks']]],
  ['otf2_5fpost_5fflush',['otf2_post_flush',['../structOTF2__FlushCallbacks.html#a5a90fca1e02d67a3c2fca21dd76db45f',1,'OTF2_FlushCallbacks']]],
  ['otf2_5fpre_5fflush',['otf2_pre_flush',['../structOTF2__FlushCallbacks.html#a82a8efae7b22c019fda1c31d886c00be',1,'OTF2_FlushCallbacks']]]
];
